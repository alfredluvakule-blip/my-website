-- ============================================================================
-- 0001_foundation.sql
-- Extensions, schemas, enums, and shared helper functions.
-- Target: Supabase PostgreSQL 15+
-- ============================================================================

create extension if not exists "pgcrypto";      -- gen_random_uuid(), digest()
create extension if not exists "pg_trgm";       -- fuzzy patient/name search
create extension if not exists "citext";        -- case-insensitive email/MRN
-- create extension if not exists "vector";     -- enable when the RAG store lands

-- Non-public schemas keep the PostgREST surface small and intentional.
create schema if not exists app;      -- helper functions, session context
create schema if not exists audit;    -- append-only trails, never exposed via API
create schema if not exists research; -- de-identified derivatives only

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------

create type app.user_role as enum (
  'administrator',
  'cardiologist',
  'cardiac_surgeon',
  'perfusionist',
  'echocardiographer',
  'sonographer',
  'cardiology_resident',
  'medical_officer',
  'nurse',
  'medical_student',
  'researcher',
  'guest'
);

create type app.study_type as enum (
  'ecg', 'tte', 'tee',
  'holter', 'stress_ecg', 'stress_echo',
  'cath', 'coronary_angio', 'cardiac_ct', 'cardiac_mri',
  'cpb_record', 'other'
);

-- Lifecycle of a study, from acquisition to a signed report.
create type app.study_status as enum (
  'registered',      -- study row exists, media may still be uploading
  'media_ready',     -- all files uploaded and virus/format checked
  'ai_queued',
  'ai_complete',
  'ai_failed',
  'awaiting_review', -- ready for a human reporter
  'in_review',
  'reported',        -- draft report authored
  'signed',          -- final, immutable
  'amended',
  'cancelled'
);

create type app.urgency as enum ('routine', 'urgent', 'critical');

create type app.severity as enum ('none', 'trivial', 'mild', 'moderate', 'severe');

create type app.sex as enum ('female', 'male', 'other', 'unknown');

create type app.ai_status as enum ('queued', 'running', 'succeeded', 'failed', 'cancelled');

-- What a human did with an AI suggestion. Drives the accuracy study later.
create type app.ai_review_outcome as enum (
  'pending',
  'accepted',        -- clinician agreed, used as-is
  'accepted_edited', -- clinician agreed after editing
  'rejected',        -- clinician disagreed
  'not_reviewed'     -- study signed without consulting the AI output
);

create type app.report_kind as enum ('preliminary', 'final', 'amendment');

create type app.consent_scope as enum ('care', 'research', 'teaching', 'ai_processing');

-- ---------------------------------------------------------------------------
-- Session context helpers
--
-- Two access paths exist:
--   1. The Express API connects with the service role and sets
--      app.current_user_id / app.current_hospital_id per transaction.
--   2. Direct Supabase client reads (dashboards, realtime) authenticate as the
--      end user, so auth.uid() is populated.
-- These helpers make both paths work under the same RLS policies.
-- ---------------------------------------------------------------------------

create or replace function app.current_user_id()
returns uuid
language sql stable
as $$
  select coalesce(
    nullif(current_setting('app.current_user_id', true), '')::uuid,
    auth.uid()
  );
$$;

create or replace function app.current_hospital_id()
returns uuid
language sql stable
as $$
  select coalesce(
    nullif(current_setting('app.current_hospital_id', true), '')::uuid,
    (select p.hospital_id from public.profiles p where p.id = app.current_user_id())
  );
$$;

create or replace function app.has_role(required variadic app.user_role[])
returns boolean
language sql stable
as $$
  select exists (
    select 1
    from public.user_roles ur
    where ur.user_id = app.current_user_id()
      and ur.revoked_at is null
      and ur.role = any(required)
  );
$$;

-- May this user see identifiable patient data at all?
create or replace function app.is_clinical_staff()
returns boolean
language sql stable
as $$
  select app.has_role(
    'administrator','cardiologist','cardiac_surgeon','perfusionist',
    'echocardiographer','sonographer','cardiology_resident',
    'medical_officer','nurse'
  );
$$;

-- Reporters: may author and sign clinical reports.
create or replace function app.can_sign_reports()
returns boolean
language sql stable
as $$
  select app.has_role('cardiologist','cardiac_surgeon','echocardiographer');
$$;

-- ---------------------------------------------------------------------------
-- updated_at trigger
-- ---------------------------------------------------------------------------

create or replace function app.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;
