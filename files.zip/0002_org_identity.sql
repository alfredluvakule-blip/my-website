-- ============================================================================
-- 0002_org_identity.sql
-- Hospitals, departments, user profiles, roles, delegated access.
-- ============================================================================

create table public.hospitals (
  id             uuid primary key default gen_random_uuid(),
  name           text not null,
  short_name     text,
  country_code   char(2) not null default 'TZ',
  timezone       text not null default 'Africa/Dar_es_Salaam',
  logo_path      text,                       -- Supabase Storage object path
  letterhead     jsonb not null default '{}'::jsonb, -- colours, address, footer text
  data_region    text not null default 'tz', -- where PHI for this tenant may live
  is_active      boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table public.departments (
  id           uuid primary key default gen_random_uuid(),
  hospital_id  uuid not null references public.hospitals(id) on delete cascade,
  name         text not null,
  code         text,
  created_at   timestamptz not null default now(),
  unique (hospital_id, name)
);

-- Mirrors auth.users. One profile per authenticated person.
create table public.profiles (
  id                uuid primary key references auth.users(id) on delete cascade,
  hospital_id       uuid references public.hospitals(id) on delete set null,
  department_id     uuid references public.departments(id) on delete set null,
  full_name         text not null,
  email             citext not null unique,
  phone             text,
  title             text,                    -- "Dr.", "Nursing Officer", ...
  registration_no   text,                    -- professional council / licence number
  signature_path    text,                    -- stored signature image, private bucket
  locale            text not null default 'en',
  mfa_enrolled      boolean not null default false,
  is_active         boolean not null default true,
  last_seen_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index on public.profiles (hospital_id);
create index profiles_name_trgm on public.profiles using gin (full_name gin_trgm_ops);

-- Roles are many-to-many and revocable, never a column on profiles.
-- Revocations are soft so the audit trail survives.
create table public.user_roles (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  role         app.user_role not null,
  hospital_id  uuid references public.hospitals(id) on delete cascade,
  granted_by   uuid references public.profiles(id),
  granted_at   timestamptz not null default now(),
  revoked_at   timestamptz,
  revoked_by   uuid references public.profiles(id)
);

create unique index user_roles_active_uniq
  on public.user_roles (user_id, role, coalesce(hospital_id, '00000000-0000-0000-0000-000000000000'::uuid))
  where revoked_at is null;

create index on public.user_roles (user_id) where revoked_at is null;

create trigger touch_hospitals before update on public.hospitals
  for each row execute function app.touch_updated_at();
create trigger touch_profiles before update on public.profiles
  for each row execute function app.touch_updated_at();
