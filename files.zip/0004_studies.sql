-- ============================================================================
-- 0004_studies.sql
-- One `studies` supertype + typed subtype tables for ECG, TTE, TEE.
--
-- Why typed columns rather than a jsonb blob: EF, TAPSE, QTc and friends are
-- queried, trended, range-checked and exported for research. Give them real
-- columns with real units. Free-text and rarely-used fields go in `extra`.
-- ============================================================================

create table public.studies (
  id             uuid primary key default gen_random_uuid(),
  hospital_id    uuid not null references public.hospitals(id) on delete restrict,
  patient_id     uuid not null references public.patients(id) on delete cascade,
  encounter_id   uuid references public.encounters(id) on delete set null,
  study_type     app.study_type not null,
  status         app.study_status not null default 'registered',
  accession_no   text,                     -- links back to RIS/PACS if present
  performed_at   timestamptz not null,
  indication     text,                     -- why the study was requested
  performed_by   uuid references public.profiles(id),   -- sonographer / technician
  requested_by   uuid references public.profiles(id),
  assigned_to    uuid references public.profiles(id),   -- reporter in the worklist
  urgency        app.urgency not null default 'routine',
  device_model   text,
  extra          jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (hospital_id, accession_no)
);

create index on public.studies (patient_id, performed_at desc);
create index studies_worklist_idx on public.studies (hospital_id, status, urgency, performed_at desc);
create index on public.studies (assigned_to) where status in ('awaiting_review','in_review');

-- Every uploaded artefact: DICOM, PDF, PNG/JPEG, phone photo, video loop.
create table public.study_files (
  id            uuid primary key default gen_random_uuid(),
  study_id      uuid not null references public.studies(id) on delete cascade,
  storage_path  text not null,             -- private Supabase Storage bucket
  mime_type     text not null,
  byte_size     bigint not null,
  sha256        text not null,             -- dedupe + integrity + AI cache key
  original_name text,
  is_dicom      boolean not null default false,
  dicom_sop_uid text,
  dicom_series_uid text,
  frame_count   integer,                   -- >1 for echo cine loops
  page_number   integer,                   -- for multi-page PDF ECGs
  phi_scrubbed  boolean not null default false, -- burned-in DICOM name/DOB removed
  uploaded_by   uuid references public.profiles(id),
  created_at    timestamptz not null default now(),
  unique (study_id, sha256)
);

create index on public.study_files (study_id);

-- ---------------------------------------------------------------------------
-- ECG
-- ---------------------------------------------------------------------------
create table public.ecg_findings (
  study_id          uuid primary key references public.studies(id) on delete cascade,

  -- Intervals & axis
  heart_rate_bpm    smallint,
  pr_ms             smallint,
  qrs_ms            smallint,
  qt_ms             smallint,
  qtc_ms            smallint,              -- Bazett unless qtc_formula says otherwise
  qtc_formula       text default 'bazett', -- bazett | fridericia | framingham | hodges
  qrs_axis_deg      smallint,
  p_axis_deg        smallint,
  t_axis_deg        smallint,

  -- Rhythm / conduction: booleans keep the worklist queryable
  rhythm            text,                  -- free-text primary rhythm label
  sinus_rhythm      boolean,
  bradycardia       boolean,
  tachycardia       boolean,
  atrial_fibrillation boolean,
  atrial_flutter    boolean,
  svt               boolean,
  avnrt             boolean,
  wpw_preexcitation boolean,
  pac               boolean,
  pvc               boolean,
  ventricular_tachycardia boolean,
  ventricular_fibrillation boolean,
  av_block_degree   text,                  -- none | 1 | 2_mobitz_1 | 2_mobitz_2 | 3
  lbbb              boolean,
  rbbb              boolean,
  fascicular_block  text,                  -- none | lafb | lpfb | bifascicular
  paced_rhythm      boolean,

  -- Morphology / ischaemia
  lvh               boolean,
  rvh               boolean,
  st_elevation_leads text[],               -- e.g. {II,III,aVF}
  st_depression_leads text[],
  t_wave_inversion_leads text[],
  pathological_q_leads text[],
  infarct_pattern   text,                  -- none | stemi_inferior | stemi_anterior | nstemi | old_mi | ...

  -- Metabolic / drug effect (suggestive only; correlate with labs)
  hyperkalaemia_pattern boolean,
  hypokalaemia_pattern  boolean,
  digoxin_effect        boolean,

  quality_notes     text,                  -- baseline wander, lead reversal, artefact
  extra             jsonb not null default '{}'::jsonb,
  updated_at        timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- TTE
-- ---------------------------------------------------------------------------
create table public.tte_measurements (
  study_id            uuid primary key references public.studies(id) on delete cascade,

  -- Left ventricle
  lvedd_mm            numeric(5,1),
  lvesd_mm            numeric(5,1),
  ivsd_mm             numeric(4,1),
  pwd_mm              numeric(4,1),
  lv_ef_pct           numeric(4,1),
  ef_method           text,                -- simpson_biplane | teichholz | visual | 3d
  fractional_shortening_pct numeric(4,1),
  stroke_volume_ml    numeric(5,1),
  cardiac_output_lmin numeric(4,2),
  cardiac_index       numeric(4,2),
  lv_mass_g           numeric(6,1),
  lv_mass_index_g_m2  numeric(5,1),
  gls_pct             numeric(4,1),        -- negative value, e.g. -18.5
  wall_motion         jsonb not null default '{}'::jsonb, -- {"segment_7":"hypokinetic", ...} 17-segment

  -- Diastolic function
  e_wave_cms          numeric(5,1),
  a_wave_cms          numeric(5,1),
  e_a_ratio           numeric(4,2),
  e_prime_septal_cms  numeric(4,1),
  e_prime_lateral_cms numeric(4,1),
  e_over_e_prime      numeric(4,1),
  diastolic_grade     text,                -- normal | grade_1 | grade_2 | grade_3 | indeterminate

  -- Right heart
  rv_basal_diam_mm    numeric(4,1),
  tapse_mm            numeric(4,1),
  rv_fac_pct          numeric(4,1),
  rv_s_prime_cms      numeric(4,1),
  rv_function         text,                -- normal | mildly_reduced | moderately_reduced | severely_reduced
  trv_max_ms          numeric(4,2),        -- tricuspid regurgitant velocity, m/s
  rvsp_mmhg           numeric(5,1),
  pulm_hypertension   text,                -- unlikely | possible | likely

  -- Atria, aorta, IVC
  la_diam_mm          numeric(4,1),
  la_volume_index_ml_m2 numeric(5,1),
  ra_area_cm2         numeric(4,1),
  aortic_root_mm      numeric(4,1),
  ascending_aorta_mm  numeric(4,1),
  ivc_diam_mm         numeric(4,1),
  ivc_collapse_pct    numeric(4,1),
  ra_pressure_mmhg    numeric(4,1),

  -- Valves: one row per valve in tte_valves below; summary flags here
  pericardial_effusion app.severity default 'none',
  tamponade_physiology boolean default false,
  pleural_effusion     text,               -- none | left | right | bilateral
  congenital_findings  text,

  image_quality       text,                -- good | adequate | poor
  extra               jsonb not null default '{}'::jsonb,
  updated_at          timestamptz not null default now()
);

-- Valve assessment is identical in shape for TTE and TEE, so it lives once.
create table public.valve_assessments (
  id              uuid primary key default gen_random_uuid(),
  study_id        uuid not null references public.studies(id) on delete cascade,
  valve           text not null check (valve in ('aortic','mitral','tricuspid','pulmonary')),
  is_prosthetic   boolean not null default false,
  prosthesis_type text,                    -- mechanical | bioprosthetic | ring | tavi | mitraclip
  morphology      text,                    -- e.g. bicuspid, rheumatic, myxomatous, calcified
  stenosis        app.severity not null default 'none',
  regurgitation   app.severity not null default 'none',
  peak_velocity_ms   numeric(4,2),
  mean_gradient_mmhg numeric(5,1),
  peak_gradient_mmhg numeric(5,1),
  valve_area_cm2     numeric(4,2),
  regurg_vc_mm       numeric(4,1),         -- vena contracta
  regurg_eroa_cm2    numeric(4,2),
  regurg_rvol_ml     numeric(5,1),
  paravalvular_leak  app.severity default 'none',
  vegetation         boolean default false,
  vegetation_size_mm numeric(4,1),
  notes           text,
  unique (study_id, valve)
);

-- ---------------------------------------------------------------------------
-- TEE
-- ---------------------------------------------------------------------------
create table public.tee_findings (
  study_id             uuid primary key references public.studies(id) on delete cascade,

  probe_insertion_ok   boolean,
  sedation             text,
  complication         text,

  laa_thrombus         text,               -- absent | present | sludge | indeterminate
  laa_emptying_vel_cms numeric(4,1),
  spontaneous_echo_contrast app.severity default 'none',
  intracardiac_thrombus_site text,
  cardiac_mass         text,               -- description; myxoma, fibroelastoma, tumour
  endocarditis         text,               -- no | possible | definite (modified Duke)
  abscess              boolean default false,

  asd                  text,               -- none | secundum | primum | sinus_venosus
  pfo                  boolean default false,
  pfo_shunt_grade      text,               -- bubble study grade
  vsd                  boolean default false,

  aortic_dissection    text,               -- none | type_a | type_b | intramural_haematoma
  aortic_atheroma_grade smallint,          -- 1-5
  pulmonary_veins      text,
  device_assessment    text,               -- Watchman / MitraClip / LAA occluder / prosthesis seating
  extra                jsonb not null default '{}'::jsonb,
  updated_at           timestamptz not null default now()
);

create trigger touch_studies before update on public.studies
  for each row execute function app.touch_updated_at();
create trigger touch_ecg before update on public.ecg_findings
  for each row execute function app.touch_updated_at();
create trigger touch_tte before update on public.tte_measurements
  for each row execute function app.touch_updated_at();
create trigger touch_tee before update on public.tee_findings
  for each row execute function app.touch_updated_at();
