# Cardiology Decision Support Platform — Architecture

**Status:** scaffold v0.1
**Audience:** you, plus whoever builds this with you.

---

## 1. Shape of the system

A **modular monolith**, not microservices. One Express API with hard internal
module boundaries, one Postgres database, and one asynchronous worker. At the
scale of a single tertiary hospital (even a national referral one), microservices
buy you distributed-systems debugging in exchange for organisational benefits you
don't need yet. Keep the *seams* clean and you can split later if you ever must.

```
                          ┌──────────────────────────┐
                          │  Next.js 15 (App Router) │
                          │  PWA · offline worklist  │
                          └───────┬──────────┬───────┘
                                  │ REST     │ Realtime (read-only)
                                  ▼          ▼
              ┌───────────────────────────┐  │
              │  Express API (TypeScript) │  │
              │  ─ auth / RBAC guard      │  │
              │  ─ patients               │  │
              │  ─ studies + media        │  │
              │  ─ reporting + signing    │  │
              │  ─ ai (enqueue / review)  │  │
              │  ─ research export        │  │
              └────┬──────────┬───────────┘  │
                   │          │ enqueue      │
                   │          ▼              │
                   │   ┌─────────────┐       │
                   │   │  AI worker  │       │
                   │   │  BullMQ +   │       │
                   │   │  Redis      │       │
                   │   └──────┬──────┘       │
                   │          │              │
                   ▼          ▼              ▼
        ┌───────────────────────────────────────────┐
        │  Supabase: Postgres (RLS) · Auth · Storage │
        └───────────────────────────────────────────┘
```

**The API is the only writer of clinical data.** It connects with the service
role and sets `app.current_user_id` / `app.current_hospital_id` per transaction.
The browser may read via Supabase directly (realtime worklist updates), and RLS
holds that line. This gives you one place to enforce business rules and one
place to write audit rows, without giving up realtime.

---

## 2. Folder structure

```
cardio/
├── apps/
│   ├── web/                      # Next.js 15, App Router
│   │   ├── app/
│   │   │   ├── (auth)/           # login, MFA, reset
│   │   │   ├── (app)/
│   │   │   │   ├── worklist/     # the screen people actually live in
│   │   │   │   ├── patients/[id]/
│   │   │   │   ├── studies/[id]/
│   │   │   │   │   ├── ecg/      # ECG reporting form + image viewer
│   │   │   │   │   ├── tte/      # measurement grid + calculators
│   │   │   │   │   └── tee/
│   │   │   │   ├── reports/[id]/ # draft → sign → PDF
│   │   │   │   ├── alerts/
│   │   │   │   ├── analytics/
│   │   │   │   └── research/
│   │   │   └── api/              # BFF only: session, file proxying. No clinical logic.
│   │   ├── components/
│   │   │   ├── viewer/           # cornerstone3d DICOM viewer wrapper
│   │   │   ├── forms/            # RHF + zod, one per study type
│   │   │   └── ui/               # shadcn
│   │   └── lib/                  # TanStack Query hooks, zustand stores
│   │
│   ├── api/                      # Express + TypeScript
│   │   └── src/
│   │       ├── modules/
│   │       │   ├── identity/     # auth guard, RBAC, profiles
│   │       │   ├── patients/
│   │       │   ├── studies/      # + media upload, DICOM ingest
│   │       │   ├── reporting/    # versions, signing, PDF
│   │       │   ├── ai/           # enqueue, fetch suggestion, record review
│   │       │   ├── alerts/
│   │       │   ├── analytics/
│   │       │   └── research/     # de-id + export, IRB-gated
│   │       ├── platform/         # db, storage, queue, logger, audit, config
│   │       └── http/             # routes, validation, openapi, error handler
│   │
│   └── worker/                   # AI jobs, PDF rendering, notification fan-out
│       └── src/jobs/
│
├── packages/
│   ├── contracts/                # zod schemas + generated TS types — the ONE
│   │                             # place ECG/TTE/TEE field definitions live.
│   │                             # Frontend forms, API validation, DB mapping,
│   │                             # AI output parsing all import from here.
│   ├── clinical/                 # pure functions: BSA, Simpson's EF, QTc,
│   │                             # valve severity grading per ASE, LV mass.
│   │                             # No I/O. 100% unit-tested. This is the part
│   │                             # that must never be wrong.
│   └── deid/                     # DICOM tag scrubbing, PHI redaction
│
├── supabase/migrations/          # the SQL you now have
└── docs/
```

Two things earn their own package because they are *correctness-critical and
shared*:

- **`packages/clinical`** — every formula. Pure, tested, no dependencies. If EF
  is computed in three places, it will disagree in three places.
- **`packages/contracts`** — a single zod schema per study type, from which the
  form, the API validator, the DB row mapper, and the AI's expected JSON output
  all derive. This is what stops the ECG form and the ECG table drifting apart.

---

## 3. The rule the schema enforces

> AI output lives in `ai_analyses`. Clinical truth lives in `ecg_findings`,
> `tte_measurements`, `tee_findings`, `report_versions`.
> **Nothing automatically copies from the first into the second.**

A reporter opens a study, sees the AI's suggestion in a clearly-marked side
panel, and either uses it, edits it, or ignores it. Whatever they do is written
to `ai_analyses.review_outcome`.

That single column gives you three things at once:

1. **Medico-legal defensibility** — the record shows a human decided.
2. **A safety valve** — if the model degrades, the acceptance rate drops and you
   see it before a patient does.
3. **Your research dataset** — accepted / accepted-edited / rejected, per
   finding, prospectively collected. That is a validation study running itself
   in the background of routine care, which is a far stronger PhD contribution
   than "we built an app."

`ai_models.is_enabled` defaults to `false` and `regulatory_status` defaults to
`investigational`. Diagnostic models stay behind an explicit flag.

---

## 4. Key flows

**Study intake**
`registered` → upload files → hash + virus scan + (if DICOM) tag scrub →
`media_ready` → optional `ai_queued` → `awaiting_review` → reporter claims it →
`in_review` → `reported` → `signed`.

DICOM PHI is scrubbed *on ingest*, before anything else touches the pixels:
burned-in name/DOB overlays get flagged (`study_files.phi_scrubbed`), and no
file leaves the hospital's storage for an external AI provider unless
`phi_scrubbed = true` **and** an `ai_processing` consent row exists.

**Signing**
Render report body → `sha256` → store as `content_hash` → HMAC/detached signature
over that hash with the signer's key → `report_signatures` row → short
`verification_code` embedded in the PDF QR. Anyone can verify the PDF against the
hash. The `report_versions` row becomes immutable by trigger; corrections are
*amendments*, never edits.

**Critical alert**
Raised by rule, clinician, or AI → `critical_alerts` row with no
`acknowledged_at` → notification fan-out → escalation clock. The alert closes
only when a human acknowledges. A notification that nobody read is not a
communicated critical finding, and the schema refuses to pretend otherwise.

**Research export**
`research.datasets` requires an `irb_reference`. `research.exports` has a trigger
that *blocks the export* without both an IRB reference and a named approver.
Exports read from de-identified views keyed on `research.subject_map.study_uid`;
the map table is revoked from all application roles.

---

## 5. Deviations from your original spec, and why

| You specified | Scaffold does | Reason |
|---|---|---|
| OpenAI as the ECG/echo interpreter | `ai_models` table, provider-agnostic, disabled by default | A general vision model is not a validated ECG algorithm. Keep the seam so you can swap in a cleared device algorithm, or your own model, without rewriting anything. |
| AI writes the report | AI writes a *suggestion*; a human writes the report | SaMD risk, TMDA, and your own liability. Also: it's what makes the accuracy study possible. |
| HIPAA/GDPR | + Tanzania **PDPA 2022**, `hospitals.data_region` | HIPAA doesn't apply to you; the PDPA does, and it has data-localisation implications for sending images to a US API. |
| Roles as a user column | `user_roles` table, revocable, soft-revoked | People hold several roles (you hold three), roles change, and revocations must survive in the audit trail. |
| Free-text everything | Typed columns + `extra jsonb` | EF, QTc and TAPSE need to be trended, range-checked and exported. Blobs can't do that. |
| 17 clinical modules | ECG / TTE / TEE tables now; `study_type` enum already lists cath, CT, MRI, Holter, CPB | The supertype pattern means adding a module = one table + one form, not a refactor. |

---

## 6. Suggested build order

1. **Identity + patients + studies + file upload.** No AI. Boring. Load-bearing.
2. **TTE reporting.** Highest volume, most structured, most immediate value — a
   good structured echo report generator that produces a branded PDF is
   *already worth deploying*, with zero AI.
3. **ECG reporting + DICOM viewer.**
4. **TEE reporting.**
5. **AI as a shadow reader** — runs, stores its suggestion, shown to nobody.
   Compare against signed reports for 3–6 months. This is your validation cohort.
6. **AI surfaced as advisory**, behind a flag, once you have local sensitivity /
   specificity numbers to put in `ai_models`.
7. RAG guideline assistant (education/reference — much lower risk than diagnosis).
8. Everything else.

Step 5 is the one to protect. It costs you almost nothing to build, it's
scientifically the right thing to do, and it turns the riskiest part of this
project into a publication.
