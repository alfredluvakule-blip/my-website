-- ============================================================================
-- 0006_workflow_audit_research.sql
-- Critical alerts, notifications, appointments, audit trail, research export.
-- ============================================================================

-- A critical finding is not a notification. It is a clinical event with an
-- acknowledgement requirement and an escalation clock.
create table public.critical_alerts (
  id             uuid primary key default gen_random_uuid(),
  study_id       uuid not null references public.studies(id) on delete cascade,
  patient_id     uuid not null references public.patients(id) on delete cascade,
  finding        text not null,             -- 'STEMI', 'LAA thrombus', 'Type A dissection'
  raised_by      text not null,             -- 'ai' | 'clinician' | 'rule'
  raised_by_user uuid references public.profiles(id),
  ai_analysis_id uuid references public.ai_analyses(id),
  raised_at      timestamptz not null default now(),

  acknowledged_by uuid references public.profiles(id),
  acknowledged_at timestamptz,
  escalated_at    timestamptz,
  escalated_to    uuid references public.profiles(id),
  resolution      text,
  closed_at       timestamptz
);

create index critical_open_idx on public.critical_alerts (raised_at)
  where acknowledged_at is null;

create table public.notifications (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  channel      text not null default 'in_app', -- in_app | email | sms | whatsapp | push
  title        text not null,
  body         text,
  link_path    text,
  study_id     uuid references public.studies(id) on delete cascade,
  alert_id     uuid references public.critical_alerts(id) on delete cascade,
  sent_at      timestamptz,
  delivered_at timestamptz,
  read_at      timestamptz,
  failed_reason text,
  created_at   timestamptz not null default now()
);

create index on public.notifications (user_id, read_at, created_at desc);

create table public.appointments (
  id            uuid primary key default gen_random_uuid(),
  patient_id    uuid not null references public.patients(id) on delete cascade,
  hospital_id   uuid not null references public.hospitals(id) on delete cascade,
  clinician_id  uuid references public.profiles(id),
  study_type    app.study_type,
  scheduled_for timestamptz not null,
  duration_min  smallint not null default 30,
  clinic        text,                       -- 'heart failure', 'pacemaker follow-up'
  status        text not null default 'scheduled', -- scheduled | arrived | done | no_show | cancelled
  notes         text,
  created_by    uuid references public.profiles(id),
  created_at    timestamptz not null default now()
);

create index on public.appointments (hospital_id, scheduled_for);

-- ---------------------------------------------------------------------------
-- Audit: append-only, PHI-access-aware, never deletable via the API.
-- ---------------------------------------------------------------------------
create table audit.events (
  id           bigserial primary key,
  occurred_at  timestamptz not null default now(),
  actor_id     uuid,                        -- may be null for system jobs
  actor_role   app.user_role,
  hospital_id  uuid,
  action       text not null,               -- read | create | update | sign | export | login | permission_change
  entity       text not null,               -- 'patients' | 'studies' | 'reports' | ...
  entity_id    uuid,
  patient_id   uuid,                        -- denormalised: "who was looked at"
  reason       text,                        -- break-glass access justification
  ip_address   inet,
  user_agent   text,
  before_state jsonb,
  after_state  jsonb
);

create index on audit.events (patient_id, occurred_at desc);
create index on audit.events (actor_id, occurred_at desc);
create index on audit.events (entity, entity_id);

revoke all on audit.events from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Research: de-identified derivatives only. The link table lives in a schema
-- that the research role cannot read.
-- ---------------------------------------------------------------------------
create table research.subject_map (
  study_uid    uuid primary key default gen_random_uuid(), -- pseudonym
  patient_id   uuid not null references public.patients(id) on delete cascade,
  salt         text not null,
  created_at   timestamptz not null default now(),
  unique (patient_id)
);

revoke all on research.subject_map from anon, authenticated;

create table research.datasets (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  description   text,
  owner_id      uuid not null references public.profiles(id),
  irb_reference text,                       -- ethics clearance number; required to export
  query_spec    jsonb not null,             -- declarative filter, not raw SQL
  created_at    timestamptz not null default now()
);

create table research.exports (
  id           uuid primary key default gen_random_uuid(),
  dataset_id   uuid not null references research.datasets(id) on delete cascade,
  requested_by uuid not null references public.profiles(id),
  format       text not null,               -- csv | xlsx | sav | rds | parquet
  row_count    integer,
  storage_path text,
  approved_by  uuid references public.profiles(id),
  approved_at  timestamptz,
  exported_at  timestamptz,
  created_at   timestamptz not null default now()
);

-- Guard: no export row may be marked exported without an approval and an IRB ref.
create or replace function research.enforce_export_approval()
returns trigger language plpgsql as $$
declare irb text;
begin
  if new.exported_at is not null then
    select d.irb_reference into irb from research.datasets d where d.id = new.dataset_id;
    if irb is null or new.approved_by is null then
      raise exception 'export blocked: dataset requires an IRB reference and an approver';
    end if;
  end if;
  return new;
end;
$$;

create trigger research_export_guard
  before insert or update on research.exports
  for each row execute function research.enforce_export_approval();
