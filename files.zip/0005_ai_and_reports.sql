-- ============================================================================
-- 0005_ai_and_reports.sql
--
-- THE LOAD-BEARING RULE OF THIS SCHEMA:
--   `ai_analyses` is a sibling of the clinical record, never a parent of it.
--   No foreign key runs from a report to an AI row as its source of truth, and
--   no trigger copies AI output into ecg_findings / tte_measurements /
--   tee_findings. A human reporter reads the suggestion, then writes the
--   finding. `ai_review_outcome` records what they did with it — which is both
--   the medico-legal trail and the raw data for a prospective accuracy study.
-- ============================================================================

create table public.ai_models (
  id             uuid primary key default gen_random_uuid(),
  key            text not null unique,      -- 'ecg-interp', 'tte-narrative', 'chat'
  provider       text not null,             -- openai | local | vendor
  model_name     text not null,
  version        text not null,
  study_types    app.study_type[] not null default '{}',
  is_diagnostic  boolean not null default false, -- true => regulated as SaMD; gate hard
  regulatory_status text not null default 'investigational',
    -- investigational | ce_marked | fda_cleared | tmda_registered | not_for_clinical_use
  validated_on   text,                      -- dataset/cohort the accuracy claim rests on
  sensitivity    numeric(4,3),              -- fill in only once measured locally
  specificity    numeric(4,3),
  disclaimer     text not null default
    'AI output is advisory only, has not been validated for diagnostic use, and must be verified by a qualified clinician.',
  is_enabled     boolean not null default false,
  created_at     timestamptz not null default now()
);

create table public.ai_analyses (
  id              uuid primary key default gen_random_uuid(),
  study_id        uuid not null references public.studies(id) on delete cascade,
  model_id        uuid not null references public.ai_models(id) on delete restrict,
  status          app.ai_status not null default 'queued',

  input_hash      text not null,            -- sha256 of files+context => idempotent replay
  input_context   jsonb not null default '{}'::jsonb, -- age, sex, K+, indication given to the model
  prompt_version  text,

  output          jsonb,                    -- structured suggestion, same shape as the findings table
  narrative       text,                     -- draft prose
  differential    jsonb,                    -- [{dx, likelihood, rationale}]
  suggested_urgency app.urgency,
  confidence      numeric(4,3),             -- model's own; treat with suspicion until calibrated
  explanation     jsonb,                    -- saliency regions, cited guideline chunks
  citations       jsonb,                    -- RAG provenance: doc, section, url

  tokens_used     integer,
  cost_usd        numeric(8,4),
  latency_ms      integer,
  error           text,

  -- Human oversight
  review_outcome  app.ai_review_outcome not null default 'pending',
  reviewed_by     uuid references public.profiles(id),
  reviewed_at     timestamptz,
  reviewer_comment text,                    -- "missed the inferior ST elevation" — gold for your study

  created_at      timestamptz not null default now(),
  completed_at    timestamptz
);

create index on public.ai_analyses (study_id, created_at desc);
create index on public.ai_analyses (status) where status in ('queued','running');
create index on public.ai_analyses (review_outcome) where review_outcome = 'pending';
create unique index ai_analyses_idempotent on public.ai_analyses (study_id, model_id, input_hash);

-- ---------------------------------------------------------------------------
-- Reports: authored by humans, versioned, immutable once signed.
-- ---------------------------------------------------------------------------
create table public.reports (
  id             uuid primary key default gen_random_uuid(),
  study_id       uuid not null references public.studies(id) on delete cascade,
  kind           app.report_kind not null default 'preliminary',
  current_version integer not null default 1,
  signed_at      timestamptz,
  signed_by      uuid references public.profiles(id),
  amends_report_id uuid references public.reports(id),
  created_at     timestamptz not null default now()
);

create index on public.reports (study_id);

create table public.report_versions (
  id              uuid primary key default gen_random_uuid(),
  report_id       uuid not null references public.reports(id) on delete cascade,
  version         integer not null,
  findings_text   text,                     -- structured findings rendered to prose
  impression      text not null,
  recommendations text,
  urgency         app.urgency not null default 'routine',

  -- Provenance: was AI involved, and how much of this text is the clinician's?
  ai_analysis_id  uuid references public.ai_analyses(id),
  ai_assisted     boolean not null default false,
  ai_text_retained_pct numeric(4,1),        -- computed by diffing draft vs final

  authored_by     uuid not null references public.profiles(id),
  authored_at     timestamptz not null default now(),
  content_hash    text not null,            -- sha256 over the rendered report body
  unique (report_id, version)
);

-- Digital signature over content_hash. Signed rows are append-only (see 0007).
create table public.report_signatures (
  id                uuid primary key default gen_random_uuid(),
  report_version_id uuid not null references public.report_versions(id) on delete restrict,
  signer_id         uuid not null references public.profiles(id),
  signer_role       app.user_role not null,
  signed_hash       text not null,
  signature         text not null,          -- detached signature / HMAC over signed_hash
  key_id            text not null,
  verification_code text not null unique,   -- short code behind the report QR
  signed_at         timestamptz not null default now()
);

create index on public.report_signatures (report_version_id);

-- Rendered PDF artefacts, cached per version.
create table public.report_exports (
  id                uuid primary key default gen_random_uuid(),
  report_version_id uuid not null references public.report_versions(id) on delete cascade,
  storage_path      text not null,
  format            text not null default 'pdf',
  generated_at      timestamptz not null default now()
);
