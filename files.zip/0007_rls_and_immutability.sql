-- ============================================================================
-- 0007_rls_and_immutability.sql
-- Row-level security (tenant + role isolation) and signed-report immutability.
--
-- RLS here is defense-in-depth, not the primary authorisation layer: the
-- Express API already checks permissions. RLS is what saves you when someone
-- ships a bug, or when the frontend talks to Supabase directly for realtime.
-- ============================================================================

alter table public.hospitals            enable row level security;
alter table public.departments          enable row level security;
alter table public.profiles             enable row level security;
alter table public.user_roles           enable row level security;
alter table public.patients             enable row level security;
alter table public.patient_identifiers  enable row level security;
alter table public.consents             enable row level security;
alter table public.encounters           enable row level security;
alter table public.problems             enable row level security;
alter table public.medications          enable row level security;
alter table public.lab_results          enable row level security;
alter table public.vitals               enable row level security;
alter table public.studies              enable row level security;
alter table public.study_files          enable row level security;
alter table public.ecg_findings         enable row level security;
alter table public.tte_measurements     enable row level security;
alter table public.tee_findings         enable row level security;
alter table public.valve_assessments    enable row level security;
alter table public.ai_analyses          enable row level security;
alter table public.reports              enable row level security;
alter table public.report_versions      enable row level security;
alter table public.report_signatures    enable row level security;
alter table public.critical_alerts      enable row level security;
alter table public.notifications        enable row level security;
alter table public.appointments         enable row level security;

-- --- Tenant scoping -------------------------------------------------------

create policy hospital_self on public.hospitals
  for select using (id = app.current_hospital_id());

create policy dept_same_hospital on public.departments
  for select using (hospital_id = app.current_hospital_id());

create policy profile_read on public.profiles
  for select using (hospital_id = app.current_hospital_id() or id = app.current_user_id());

create policy profile_self_update on public.profiles
  for update using (id = app.current_user_id());

create policy roles_read on public.user_roles
  for select using (user_id = app.current_user_id() or app.has_role('administrator'));

create policy roles_admin_write on public.user_roles
  for all using (app.has_role('administrator')) with check (app.has_role('administrator'));

-- --- Patients: clinical staff only, own hospital only ----------------------

create policy patients_read on public.patients
  for select using (hospital_id = app.current_hospital_id() and app.is_clinical_staff());

create policy patients_write on public.patients
  for all using (hospital_id = app.current_hospital_id() and app.is_clinical_staff())
  with check (hospital_id = app.current_hospital_id() and app.is_clinical_staff());

-- Direct identifiers: narrower still. Students and researchers never see these.
create policy identifiers_read on public.patient_identifiers
  for select using (
    app.is_clinical_staff()
    and exists (
      select 1 from public.patients p
      where p.id = patient_id and p.hospital_id = app.current_hospital_id()
    )
  );

create policy identifiers_write on public.patient_identifiers
  for all using (app.is_clinical_staff()) with check (app.is_clinical_staff());

-- --- Patient-linked clinical tables: one reusable predicate ----------------

create or replace function app.patient_in_scope(p uuid)
returns boolean language sql stable as $$
  select app.is_clinical_staff()
     and exists (select 1 from public.patients pt
                 where pt.id = p and pt.hospital_id = app.current_hospital_id());
$$;

create policy consents_scope on public.consents
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));
create policy encounters_scope on public.encounters
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));
create policy problems_scope on public.problems
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));
create policy medications_scope on public.medications
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));
create policy labs_scope on public.lab_results
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));
create policy vitals_scope on public.vitals
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));

-- --- Studies and their children -------------------------------------------

create policy studies_scope on public.studies
  for all using (hospital_id = app.current_hospital_id() and app.is_clinical_staff())
  with check (hospital_id = app.current_hospital_id() and app.is_clinical_staff());

create or replace function app.study_in_scope(s uuid)
returns boolean language sql stable as $$
  select exists (select 1 from public.studies st
                 where st.id = s
                   and st.hospital_id = app.current_hospital_id()
                   and app.is_clinical_staff());
$$;

create policy files_scope on public.study_files
  for all using (app.study_in_scope(study_id)) with check (app.study_in_scope(study_id));
create policy ecg_scope on public.ecg_findings
  for all using (app.study_in_scope(study_id)) with check (app.study_in_scope(study_id));
create policy tte_scope on public.tte_measurements
  for all using (app.study_in_scope(study_id)) with check (app.study_in_scope(study_id));
create policy tee_scope on public.tee_findings
  for all using (app.study_in_scope(study_id)) with check (app.study_in_scope(study_id));
create policy valves_scope on public.valve_assessments
  for all using (app.study_in_scope(study_id)) with check (app.study_in_scope(study_id));
create policy ai_scope on public.ai_analyses
  for select using (app.study_in_scope(study_id));

-- --- Reports ---------------------------------------------------------------

create policy reports_read on public.reports
  for select using (app.study_in_scope(study_id));

create policy report_versions_read on public.report_versions
  for select using (exists (select 1 from public.reports r
                            where r.id = report_id and app.study_in_scope(r.study_id)));

-- Only reporters may author a version.
create policy report_versions_write on public.report_versions
  for insert with check (
    app.can_sign_reports()
    and authored_by = app.current_user_id()
    and exists (select 1 from public.reports r
                where r.id = report_id and app.study_in_scope(r.study_id))
  );

create policy signatures_read on public.report_signatures
  for select using (exists (select 1 from public.report_versions rv
                            join public.reports r on r.id = rv.report_id
                            where rv.id = report_version_id and app.study_in_scope(r.study_id)));

-- --- Alerts, notifications, appointments ----------------------------------

create policy alerts_scope on public.critical_alerts
  for all using (app.patient_in_scope(patient_id)) with check (app.patient_in_scope(patient_id));

create policy notif_own on public.notifications
  for all using (user_id = app.current_user_id()) with check (user_id = app.current_user_id());

create policy appts_scope on public.appointments
  for all using (hospital_id = app.current_hospital_id() and app.is_clinical_staff())
  with check (hospital_id = app.current_hospital_id() and app.is_clinical_staff());

-- ============================================================================
-- Immutability
-- ============================================================================

-- A report version, once signed, cannot be edited or deleted. Corrections are
-- made by issuing an amendment (a new `reports` row with amends_report_id set).
create or replace function app.block_signed_report_mutation()
returns trigger language plpgsql as $$
begin
  if exists (select 1 from public.report_signatures s
             where s.report_version_id = coalesce(old.id, new.id)) then
    raise exception 'report version % is signed and immutable; issue an amendment instead', old.id;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

create trigger report_versions_immutable
  before update or delete on public.report_versions
  for each row execute function app.block_signed_report_mutation();

-- Signatures and audit events are append-only, full stop.
create or replace function app.block_mutation()
returns trigger language plpgsql as $$
begin
  raise exception 'table % is append-only', tg_table_name;
end;
$$;

create trigger signatures_append_only
  before update or delete on public.report_signatures
  for each row execute function app.block_mutation();

create trigger audit_append_only
  before update or delete on audit.events
  for each row execute function app.block_mutation();

-- A study cannot leave 'signed' except into 'amended'.
create or replace function app.guard_study_status()
returns trigger language plpgsql as $$
begin
  if old.status = 'signed' and new.status not in ('signed','amended') then
    raise exception 'signed study % cannot revert to %', old.id, new.status;
  end if;
  return new;
end;
$$;

create trigger studies_status_guard
  before update on public.studies
  for each row execute function app.guard_study_status();
