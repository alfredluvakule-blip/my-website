-- ============================================================================
-- 0003_patients_clinical.sql
-- Patients, encounters, problems, medications, labs, vitals, consent.
--
-- Design note: direct identifiers (national ID, phone) are kept in a separate
-- table from the clinical record so that (a) they can be encrypted / locked
-- down independently and (b) the research de-identification job never has to
-- touch a table that mixes the two.
-- ============================================================================

create table public.patients (
  id                 uuid primary key default gen_random_uuid(),
  hospital_id        uuid not null references public.hospitals(id) on delete restrict,
  mrn                citext not null,             -- hospital number
  date_of_birth      date,
  birth_year         smallint generated always as (extract(year from date_of_birth)::smallint) stored,
  sex                app.sex not null default 'unknown',
  deceased_at        date,
  is_active          boolean not null default true,
  created_by         uuid references public.profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  unique (hospital_id, mrn)
);

create index on public.patients (hospital_id);

-- Direct identifiers. Restricted table; excluded from every research view.
create table public.patient_identifiers (
  patient_id      uuid primary key references public.patients(id) on delete cascade,
  given_name      text not null,
  family_name     text not null,
  other_names     text,
  national_id     text,
  phone           text,
  next_of_kin     text,
  next_of_kin_phone text,
  address         text,
  updated_at      timestamptz not null default now()
);

create index patient_ident_name_trgm on public.patient_identifiers
  using gin ((given_name || ' ' || family_name) gin_trgm_ops);

-- Consent is per patient, per scope, and expires.
create table public.consents (
  id           uuid primary key default gen_random_uuid(),
  patient_id   uuid not null references public.patients(id) on delete cascade,
  scope        app.consent_scope not null,
  granted      boolean not null,
  document_path text,                      -- scanned signed form
  recorded_by  uuid not null references public.profiles(id),
  effective_from timestamptz not null default now(),
  expires_at   timestamptz,
  withdrawn_at timestamptz,
  notes        text
);

create index on public.consents (patient_id, scope);

-- A visit / admission. Studies hang off encounters when one exists.
create table public.encounters (
  id            uuid primary key default gen_random_uuid(),
  patient_id    uuid not null references public.patients(id) on delete cascade,
  hospital_id   uuid not null references public.hospitals(id) on delete restrict,
  department_id uuid references public.departments(id),
  encounter_type text not null default 'outpatient', -- outpatient | inpatient | icu | theatre | emergency
  admitted_at   timestamptz,
  discharged_at timestamptz,
  attending_id  uuid references public.profiles(id),
  created_at    timestamptz not null default now()
);

create index on public.encounters (patient_id, admitted_at desc);

create table public.problems (
  id           uuid primary key default gen_random_uuid(),
  patient_id   uuid not null references public.patients(id) on delete cascade,
  description  text not null,
  icd10_code   text,
  onset_date   date,
  resolved_date date,
  recorded_by  uuid references public.profiles(id),
  created_at   timestamptz not null default now()
);

create table public.medications (
  id           uuid primary key default gen_random_uuid(),
  patient_id   uuid not null references public.patients(id) on delete cascade,
  drug_name    text not null,
  dose         text,
  route        text,
  frequency    text,
  started_on   date,
  stopped_on   date,
  recorded_by  uuid references public.profiles(id),
  created_at   timestamptz not null default now()
);

create index on public.medications (patient_id) where stopped_on is null;

-- Labs matter clinically here: K+/Ca2+ change how an ECG should be read, and
-- the AI layer must be able to see them as context rather than guess.
create table public.lab_results (
  id            uuid primary key default gen_random_uuid(),
  patient_id    uuid not null references public.patients(id) on delete cascade,
  encounter_id  uuid references public.encounters(id) on delete set null,
  analyte       text not null,          -- 'potassium', 'creatinine', 'troponin_hs', ...
  value_num     numeric,
  value_text    text,
  unit          text,
  ref_low       numeric,
  ref_high      numeric,
  abnormal_flag text,                   -- L | H | LL | HH
  collected_at  timestamptz not null,
  created_at    timestamptz not null default now()
);

create index on public.lab_results (patient_id, analyte, collected_at desc);

create table public.vitals (
  id            uuid primary key default gen_random_uuid(),
  patient_id    uuid not null references public.patients(id) on delete cascade,
  encounter_id  uuid references public.encounters(id) on delete set null,
  recorded_at   timestamptz not null default now(),
  heart_rate    smallint,
  systolic_bp   smallint,
  diastolic_bp  smallint,
  resp_rate     smallint,
  spo2          smallint,
  temperature_c numeric(4,1),
  height_cm     numeric(5,1),
  weight_kg     numeric(5,1),
  bsa_m2        numeric(4,2),            -- Du Bois; computed in the API, stored for indexing
  recorded_by   uuid references public.profiles(id)
);

create index on public.vitals (patient_id, recorded_at desc);

create trigger touch_patients before update on public.patients
  for each row execute function app.touch_updated_at();
create trigger touch_patient_identifiers before update on public.patient_identifiers
  for each row execute function app.touch_updated_at();
